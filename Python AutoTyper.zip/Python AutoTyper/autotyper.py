from pynput.keyboard import Key, Controller
import time

keyboard = Controller()

time.sleep(3)

keyboard.type("Insert text here")